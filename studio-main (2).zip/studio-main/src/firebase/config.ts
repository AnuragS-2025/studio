export const firebaseConfig = {
  "projectId": "studio-2992095150-452ba",
  "appId": "1:513729394445:web:e68adba76432ea803d6244",
  "apiKey": "AIzaSyDqgpvGBA2jkyUL9A-wOXwg1PyZ0Kg7-V4",
  "authDomain": "studio-2992095150-452ba.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "513729394445"
};
